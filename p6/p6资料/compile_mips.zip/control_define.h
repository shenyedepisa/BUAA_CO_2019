//
// Created by ym500 on 2019/11/16.
//

#ifndef UNTITLED_CONTROL_DEFINE_H
#define UNTITLED_CONTROL_DEFINE_H

const int print_syntax = 0;
const int print_split = 0;
const int print_error = 0;
const int debug = 0;
#endif //UNTITLED_CONTROL_DEFINE_H
