//
// Created by ym500 on 2019/11/19.
//

#ifndef UNTITLED_MIPS_H
#define UNTITLED_MIPS_H
void produce_mips();
#endif //UNTITLED_MIPS_H
